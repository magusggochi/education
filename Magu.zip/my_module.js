function moduleAdd (a,b){

    return a+b;
}

function moduleSub (a,b){

    return a-b;
}

function moduleMul(a,b){

    return a*b;
}

function moduleDiv(a,b){
    return a/b;
}

// 이건 충돌이 안나나요?